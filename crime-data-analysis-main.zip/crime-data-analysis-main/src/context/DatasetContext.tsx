import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { CrimeRecord, mockCrimeData } from "@/data/mockCrimeData";

const BACKEND_BASE_URL = "http://127.0.0.1:8000";

type BackendUploadResponse = {
  records: CrimeRecord[];
  center: { lat: number; lng: number } | null;
  dropped_invalid_coords: number;
};

type DatasetContextValue = {
  records: CrimeRecord[];
  center: { lat: number; lng: number } | null;
  droppedInvalidCoords: number;
  source: "mock" | "uploaded";
  uploadCsv: (file: File) => Promise<void>;
  clearUploaded: () => void;
};

const DatasetContext = createContext<DatasetContextValue | null>(null);

const LS_KEY = "crimevision.dataset.v1";

function safeParse(json: string | null): Partial<BackendUploadResponse> | null {
  if (!json) return null;
  try {
    return JSON.parse(json) as Partial<BackendUploadResponse>;
  } catch {
    return null;
  }
}

function normalizeHeaderCell(s: string) {
  return s
    .trim()
    .replace(/^\uFEFF/, "") // BOM
    .replace(/^"(.*)"$/, "$1")
    .replace(/^'(.*)'$/, "$1")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

async function validateCsvHeaders(file: File) {
  const text = await file.slice(0, 128 * 1024).text();
  const firstLine = text.split(/\r?\n/).find(l => l.trim().length > 0) ?? "";

  // Detect delimiter (comma/semicolon/tab)
  const delimCandidates: Array<"," | ";" | "\t"> = [",", ";", "\t"];
  const bestDelim =
    delimCandidates
      .map(d => ({ d, count: firstLine.split(d).length - 1 }))
      .sort((a, b) => b.count - a.count)[0]?.d ?? ",";

  const headers = firstLine.split(bestDelim).map(normalizeHeaderCell).filter(Boolean);

  const hasAny = (cands: string[]) => cands.some(c => headers.includes(c));

  const okDate = hasAny(["date", "datetime", "timestamp"]);
  const okType = hasAny(["primary type", "crime type", "type", "crimetype"]);
  const okLat = hasAny(["latitude", "lat"]);
  const okLon = hasAny(["longitude", "lon", "lng"]);

  const missing: string[] = [];
  if (!okDate) missing.push("Date");
  if (!okType) missing.push("Primary Type / Crime Type");
  if (!okLat) missing.push("Latitude");
  if (!okLon) missing.push("Longitude");

  if (missing.length > 0) {
    throw new Error(
      `CSV is missing required columns: ${missing.join(", ")}. ` +
        `Accepted examples: Date (or Datetime/Timestamp), Primary Type (or Crime Type), Latitude/Lat, Longitude/Lon/Lng.`
    );
  }
}

function sleep(ms: number) {
  return new Promise<void>(resolve => window.setTimeout(resolve, ms));
}

async function assertBackendReachable(opts?: { attempts?: number; timeoutMs?: number }) {
  const attempts = opts?.attempts ?? 3;
  const timeoutMs = opts?.timeoutMs ?? 10_000;

  let lastErr: unknown = null;
  for (let i = 1; i <= attempts; i++) {
    const controller = new AbortController();
    const t = window.setTimeout(() => controller.abort(), timeoutMs);
    const started = performance.now();
    try {
      console.info("[uploadCsv] health check", { attempt: i, url: `${BACKEND_BASE_URL}/health`, timeoutMs });
      const res = await fetch(`${BACKEND_BASE_URL}/health`, {
        signal: controller.signal,
        cache: "no-store",
      });
      const ms = Math.round(performance.now() - started);
      console.info("[uploadCsv] health check result", { attempt: i, ok: res.ok, status: res.status, ms });
      if (!res.ok) throw new Error(`Backend not ready (${res.status})`);
      return;
    } catch (e) {
      lastErr = e;
      const ms = Math.round(performance.now() - started);
      console.error("[uploadCsv] health check failed", { attempt: i, ms, error: e });
      if (i < attempts) {
        // small backoff to handle backend just starting/reloading
        await sleep(500 * i);
      }
    } finally {
      window.clearTimeout(t);
    }
  }

  const hint = `Backend is not reachable at ${BACKEND_BASE_URL}. Start the backend and try again.`;
  if (lastErr instanceof DOMException && lastErr.name === "AbortError") {
    throw new Error(`${hint} (Health check timed out after ${timeoutMs / 1000}s)`);
  }
  throw new Error(hint);
}

export function DatasetProvider({ children }: { children: React.ReactNode }) {
  const [records, setRecords] = useState<CrimeRecord[]>(mockCrimeData);
  const [center, setCenter] = useState<{ lat: number; lng: number } | null>(null);
  const [droppedInvalidCoords, setDroppedInvalidCoords] = useState(0);
  const [source, setSource] = useState<"mock" | "uploaded">("mock");

  useEffect(() => {
    const cached = safeParse(localStorage.getItem(LS_KEY));
    if (cached?.records && Array.isArray(cached.records) && cached.records.length > 0) {
      setRecords(cached.records as CrimeRecord[]);
      setCenter((cached.center as any) ?? null);
      setDroppedInvalidCoords(Number(cached.dropped_invalid_coords ?? 0));
      setSource("uploaded");
    }
  }, []);

  const uploadCsv = useCallback(async (file: File) => {
    if (!file) throw new Error("No file selected.");
    const nameOk = file.name.toLowerCase().endsWith(".csv");
    const typeOk = file.type === "text/csv" || file.type === "application/vnd.ms-excel" || file.type === "";
    if (!nameOk && !typeOk) {
      throw new Error("Please select a CSV file.");
    }

    await validateCsvHeaders(file);
    // Note: we intentionally do NOT block on /health here.
    // If the backend is up, the upload will succeed; if not, fetch() will fail and we surface that error.

    const form = new FormData();
    form.append("file", file);

    // Timeout: large files can legitimately take a while even on localhost.
    // Keep a cap to avoid infinite pending requests, but scale with size.
    const controller = new AbortController();
    const timeoutMs =
      file.size < 5 * 1024 * 1024
        ? 120_000 // <= 5MB
        : file.size < 200 * 1024 * 1024
          ? 600_000 // <= 200MB
          : 1_800_000; // > 200MB (30 min)
    const t = window.setTimeout(() => controller.abort(), timeoutMs);

    let res: Response;
    try {
      // Debug logs to help diagnose "stuck" uploads
      const started = performance.now();
      console.info("[uploadCsv] POST /upload", { url: `${BACKEND_BASE_URL}/upload`, name: file.name, size: file.size, type: file.type, timeoutMs });
      res = await fetch(`${BACKEND_BASE_URL}/upload`, {
        method: "POST",
        body: form,
        signal: controller.signal,
      });
      const ms = Math.round(performance.now() - started);
      console.info("[uploadCsv] response", { ok: res.ok, status: res.status, ms });
    } catch (e) {
      console.error("[uploadCsv] request failed", e);
      if (e instanceof DOMException && e.name === "AbortError") {
        throw new Error(`Upload timed out after ${Math.round(timeoutMs / 1000)}s. Please try again.`);
      }
      // Typical cases: backend not running, CORS, network error
      throw e instanceof Error ? e : new Error("Upload failed. Please try again later.");
    } finally {
      window.clearTimeout(t);
    }

    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      console.error("[uploadCsv] error body", txt);
      try {
        const maybeJson = JSON.parse(txt) as { detail?: string };
        if (maybeJson?.detail) throw new Error(maybeJson.detail);
      } catch {
        // ignore JSON parse
      }
      throw new Error(txt || `Upload failed (${res.status})`);
    }

    const data = (await res.json()) as BackendUploadResponse;
    console.info("[uploadCsv] parsed", {
      records: Array.isArray(data.records) ? data.records.length : "invalid",
      center: data.center,
      dropped_invalid_coords: data.dropped_invalid_coords,
    });
    setRecords(data.records);
    setCenter(data.center);
    setDroppedInvalidCoords(data.dropped_invalid_coords || 0);
    setSource("uploaded");
    localStorage.setItem(LS_KEY, JSON.stringify(data));
  }, []);

  const clearUploaded = useCallback(() => {
    setRecords(mockCrimeData);
    setCenter(null);
    setDroppedInvalidCoords(0);
    setSource("mock");
    localStorage.removeItem(LS_KEY);
  }, []);

  const value = useMemo(
    () => ({ records, center, droppedInvalidCoords, source, uploadCsv, clearUploaded }),
    [records, center, droppedInvalidCoords, source, uploadCsv, clearUploaded]
  );

  return <DatasetContext.Provider value={value}>{children}</DatasetContext.Provider>;
}

export function useDataset() {
  const ctx = useContext(DatasetContext);
  if (!ctx) throw new Error("useDataset must be used within DatasetProvider");
  return ctx;
}

