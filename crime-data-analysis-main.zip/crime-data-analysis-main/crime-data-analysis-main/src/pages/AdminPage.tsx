import { useCallback, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getMetrics } from "@/data/mockCrimeData";
import { Upload, Database, Settings, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useDataset } from "@/context/DatasetContext";
import { useToast } from "@/hooks/use-toast";

export default function AdminPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { records, uploadCsv, droppedInvalidCoords } = useDataset();
  const metrics = getMetrics(records);
  const [filters, setFilters] = useState({ crimeType: true, dateRange: true, location: true, heatmap: true });
  const [isUploading, setIsUploading] = useState(false);
  const [pickedFile, setPickedFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const toggle = (key: keyof typeof filters) => setFilters(f => ({ ...f, [key]: !f[key] }));

  const isCsv = (f: File) => {
    const nameOk = f.name.toLowerCase().endsWith(".csv");
    const typeOk = f.type === "text/csv" || f.type === "application/vnd.ms-excel" || f.type === "";
    return nameOk || typeOk;
  };

  const doUpload = useCallback(async (f: File) => {
    if (!isCsv(f)) {
      toast({
        variant: "destructive",
        title: "Invalid file",
        description: "Please upload a CSV file.",
      });
      return;
    }

    setIsUploading(true);
    try {
      await uploadCsv(f);
      toast({
        title: "Upload complete",
        description: `Processed ${f.name}${droppedInvalidCoords ? ` (dropped ${droppedInvalidCoords} invalid coords)` : ""}.`,
      });
      navigate("/dashboard");
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: err instanceof Error ? err.message : "Could not upload CSV.",
      });
    } finally {
      setIsUploading(false);
      setPickedFile(null);
      if (fileRef.current) fileRef.current.value = "";
    }
  }, [droppedInvalidCoords, navigate, toast, uploadCsv]);

  return (
    <div className="container py-8 space-y-6 max-w-4xl">
      <h1 className="text-2xl font-bold">Admin Panel</h1>

      {/* Upload */}
      <div className="glass-card rounded-xl p-6 space-y-4 animate-fade-in">
        <div className="flex items-center gap-2">
          <Upload className="h-5 w-5 text-primary" />
          <h2 className="font-semibold text-lg">Upload New Dataset</h2>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={e => {
            const f = e.target.files?.[0];
            if (!f) return;
            setPickedFile(f);
          }}
        />
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
            dragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
          } ${isUploading ? "opacity-60 pointer-events-none" : ""}`}
          onClick={() => fileRef.current?.click()}
          onDragOver={e => {
            e.preventDefault();
            if (!isUploading) setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={e => {
            e.preventDefault();
            setDragging(false);
            if (isUploading) return;
            const f = e.dataTransfer.files?.[0];
            if (f) {
              setPickedFile(f);
              void doUpload(f);
            }
          }}
          role="button"
          tabIndex={0}
          onKeyDown={e => {
            if (e.key === "Enter" || e.key === " ") fileRef.current?.click();
          }}
        >
          <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            {isUploading ? "Uploading & processing…" : pickedFile ? `Selected: ${pickedFile.name}` : "Drag & drop CSV file here or click to browse"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            className="gap-2"
            disabled={!pickedFile || isUploading}
            onClick={() => {
              if (!pickedFile) return;
              void doUpload(pickedFile);
            }}
          >
            <Check className="h-4 w-4" />
            {isUploading ? "Processing…" : "Upload & Process"}
          </Button>
          <Button
            variant="outline"
            disabled={isUploading}
            onClick={() => {
              setPickedFile(null);
              if (fileRef.current) fileRef.current.value = "";
            }}
          >
            Clear
          </Button>
        </div>
      </div>

      {/* Dataset Summary */}
      <div className="glass-card rounded-xl p-6 space-y-4 animate-fade-in" style={{ animationDelay: "100ms" }}>
        <div className="flex items-center gap-2">
          <Database className="h-5 w-5 text-primary" />
          <h2 className="font-semibold text-lg">Dataset Summary</h2>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { label: "Total Records", value: metrics.total },
            { label: "Crime Types", value: Object.keys(metrics.typeCounts).length },
            { label: "Locations", value: Object.keys(metrics.areaCounts).length },
            { label: "Date Range", value: "2024-01 to 2024-12" },
          ].map(item => (
            <div key={item.label} className="flex justify-between items-center p-3 rounded-lg bg-muted/30">
              <span className="text-sm text-muted-foreground">{item.label}</span>
              <Badge variant="secondary">{item.value}</Badge>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Toggles */}
      <div className="glass-card rounded-xl p-6 space-y-4 animate-fade-in" style={{ animationDelay: "200ms" }}>
        <div className="flex items-center gap-2">
          <Settings className="h-5 w-5 text-primary" />
          <h2 className="font-semibold text-lg">Feature Toggles</h2>
        </div>
        <div className="space-y-3">
          {Object.entries(filters).map(([key, val]) => (
            <div key={key} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
              <span className="text-sm capitalize">{key.replace(/([A-Z])/g, " $1").trim()} Filter</span>
              <Switch checked={val} onCheckedChange={() => toggle(key as keyof typeof filters)} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
