import { useEffect, useRef, useMemo, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet.heat";
import type { CrimeRecord } from "@/data/mockCrimeData";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, AlertTriangle, Layers, MapPin, Flame } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useDataset } from "@/context/DatasetContext";

function isValidCoord(r: CrimeRecord): boolean {
  if (r.latitude == null || r.longitude == null) return false;
  if (r.latitude === 0 && r.longitude === 0) return false;
  if (r.latitude < -90 || r.latitude > 90) return false;
  if (r.longitude < -180 || r.longitude > 180) return false;
  return true;
}

export default function HotspotMapPage() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);
  const heatLayerRef = useRef<any>(null);
  const markerLayerRef = useRef<L.LayerGroup | null>(null);

  const { records, center } = useDataset();

  const [crimeType, setCrimeType] = useState("all");
  const [location, setLocation] = useState("all");
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [showMarkers, setShowMarkers] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  const crimeTypeOptions = useMemo(() => {
    const s = new Set<string>();
    records.forEach(r => s.add(r.crimeType));
    return Array.from(s).sort((a, b) => a.localeCompare(b));
  }, [records]);

  const locationOptions = useMemo(() => {
    const s = new Set<string>();
    records.forEach(r => s.add(r.location));
    return Array.from(s).sort((a, b) => a.localeCompare(b));
  }, [records]);

  const filtered = useMemo(() => {
    return records.filter(r => {
      if (crimeType !== "all" && r.crimeType !== crimeType) return false;
      if (location !== "all" && r.location !== location) return false;
      return true;
    });
  }, [records, crimeType, location]);

  const validData = useMemo(() => filtered.filter(isValidCoord), [filtered]);
  const invalidCount = filtered.length - validData.length;

  // Calculate dynamic bounds
  const bounds = useMemo(() => {
    if (validData.length === 0) return null;
    const lats = validData.map(r => r.latitude);
    const lngs = validData.map(r => r.longitude);
    return L.latLngBounds(
      [Math.min(...lats), Math.min(...lngs)],
      [Math.max(...lats), Math.max(...lngs)]
    );
  }, [validData]);

  // Init map once
  useEffect(() => {
    if (!mapRef.current) return;
    if (mapInstance.current) return;

    const initialCenter: [number, number] = center ? [center.lat, center.lng] : [20, 78];
    const map = L.map(mapRef.current).setView(initialCenter, center ? 11 : 5);
    mapInstance.current = map;

    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
    }).addTo(map);

    markerLayerRef.current = L.layerGroup().addTo(map);

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  // If backend provides a center, use it when it changes (e.g., after upload)
  useEffect(() => {
    const map = mapInstance.current;
    if (!map || !center) return;
    map.setView([center.lat, center.lng], Math.max(map.getZoom(), 11), { animate: true });
  }, [center]);

  // Update layers when data/toggles change
  useEffect(() => {
    const map = mapInstance.current;
    if (!map) return;

    setIsLoading(true);

    // Fit bounds
    if (bounds) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }

    // Remove old heat layer
    if (heatLayerRef.current) {
      map.removeLayer(heatLayerRef.current);
      heatLayerRef.current = null;
    }

    // Clear markers
    markerLayerRef.current?.clearLayers();

    // Heatmap
    if (showHeatmap && validData.length > 0) {
      const heatPoints: [number, number, number][] = validData.map(r => [
        r.latitude,
        r.longitude,
        r.severity === "high" ? 1 : r.severity === "medium" ? 0.6 : 0.3,
      ]);
      heatLayerRef.current = L.heatLayer(heatPoints, {
        radius: 20,
        blur: 15,
        maxZoom: 15,
        gradient: { 0.2: "#2563eb", 0.5: "#10b981", 0.8: "#f59e0b", 1: "#ef4444" },
      }).addTo(map);
    }

    // Markers (cap at 300 for perf)
    if (showMarkers) {
      const capped = validData.slice(0, 300);
      const dangerIcon = L.divIcon({
        className: "",
        html: `<div style="background:hsl(0,72%,55%);width:10px;height:10px;border-radius:50%;border:2px solid white;"></div>`,
        iconSize: [10, 10],
      });
      const normalIcon = L.divIcon({
        className: "",
        html: `<div style="background:hsl(210,100%,55%);width:8px;height:8px;border-radius:50%;border:2px solid white;"></div>`,
        iconSize: [8, 8],
      });
      capped.forEach(r => {
        L.marker([r.latitude, r.longitude], {
          icon: r.severity === "high" ? dangerIcon : normalIcon,
        })
          .bindPopup(
            `<div style="color:#333"><strong>${r.crimeType}</strong><br/>${r.location}<br/>${r.date} ${r.time}${r.severity === "high" ? '<br/><span style="color:red;font-weight:bold">⚠ High Risk</span>' : ""}</div>`
          )
          .addTo(markerLayerRef.current!);
      });
    }

    // Simulate brief loading
    const t = setTimeout(() => setIsLoading(false), 300);
    return () => clearTimeout(t);
  }, [validData, bounds, showHeatmap, showMarkers]);

  return (
    <div className="container py-8 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Crime Hotspot Map</h1>
          <p className="text-muted-foreground text-sm">
            Showing {validData.length} valid crime locations
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={crimeType} onValueChange={setCrimeType}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {crimeTypeOptions.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={location} onValueChange={setLocation}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              {locationOptions.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Warnings */}
      {invalidCount > 0 && (
        <Alert variant="destructive" className="border-destructive/30 bg-destructive/10">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {invalidCount} data point{invalidCount > 1 ? "s were" : " was"} removed due to invalid location values.
          </AlertDescription>
        </Alert>
      )}

      {/* Layer toggles + Legend */}
      <div className="flex flex-wrap items-center gap-6">
        <div className="flex items-center gap-2">
          <Switch id="heatmap" checked={showHeatmap} onCheckedChange={setShowHeatmap} />
          <Label htmlFor="heatmap" className="flex items-center gap-1 text-sm cursor-pointer">
            <Flame className="h-3.5 w-3.5" /> Heatmap
          </Label>
        </div>
        <div className="flex items-center gap-2">
          <Switch id="markers" checked={showMarkers} onCheckedChange={setShowMarkers} />
          <Label htmlFor="markers" className="flex items-center gap-1 text-sm cursor-pointer">
            <MapPin className="h-3.5 w-3.5" /> Markers
          </Label>
        </div>
        <div className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
          <Layers className="h-3.5 w-3.5" />
          <span>Intensity:</span>
          <div className="flex gap-0.5">
            {["#2563eb", "#10b981", "#f59e0b", "#ef4444"].map(c => (
              <div key={c} className="w-5 h-3 rounded-sm" style={{ background: c }} />
            ))}
          </div>
          <span>Low → High</span>
        </div>
      </div>

      {/* Map or empty state */}
      {validData.length === 0 && !isLoading ? (
        <div className="glass-card rounded-xl flex items-center justify-center" style={{ height: "calc(100vh - 18rem)" }}>
          <div className="text-center space-y-2">
            <MapPin className="h-10 w-10 mx-auto text-muted-foreground" />
            <p className="text-muted-foreground">No valid location data available</p>
          </div>
        </div>
      ) : (
        <div className="glass-card rounded-xl overflow-hidden relative" style={{ height: "calc(100vh - 18rem)" }}>
          {isLoading && (
            <div className="absolute inset-0 z-[1000] flex items-center justify-center bg-background/60 backdrop-blur-sm">
              <div className="flex flex-col items-center gap-2">
                <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                <span className="text-sm text-muted-foreground">Loading map…</span>
              </div>
            </div>
          )}
          <div ref={mapRef} className="w-full h-full" />
        </div>
      )}
    </div>
  );
}
