import { useMemo, useRef, useState } from "react";
import { getInsights, getMetrics, getMonthlyTrends } from "@/data/mockCrimeData";
import { MetricCards } from "@/components/dashboard/MetricCards";
import { CrimeCharts } from "@/components/dashboard/CrimeCharts";
import { CrimeTable } from "@/components/dashboard/CrimeTable";
import { InsightsPanel } from "@/components/dashboard/InsightsPanel";
import { DashboardFilters } from "@/components/dashboard/DashboardFilters";
import { BarChart3, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useDataset } from "@/context/DatasetContext";

export default function DashboardPage() {
  const { toast } = useToast();
  const { records, source, droppedInvalidCoords, uploadCsv, clearUploaded } = useDataset();
  const [view, setView] = useState<"chart" | "table">("chart");
  const [crimeTypeFilter, setCrimeTypeFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  const crimeTypeOptions = useMemo(() => {
    const s = new Set<string>();
    records.forEach(r => s.add(r.crimeType));
    return Array.from(s).sort((a, b) => a.localeCompare(b));
  }, [records]);

  const locationOptions = useMemo(() => {
    const s = new Set<string>();
    records.forEach(r => s.add(r.location));
    return Array.from(s).sort((a, b) => a.localeCompare(b));
  }, [records]);

  const filteredData = useMemo(() => {
    return records.filter(r => {
      if (crimeTypeFilter !== "all" && r.crimeType !== crimeTypeFilter) return false;
      if (locationFilter !== "all" && r.location !== locationFilter) return false;
      if (dateRange.from && new Date(r.date) < dateRange.from) return false;
      if (dateRange.to && new Date(r.date) > dateRange.to) return false;
      return true;
    });
  }, [records, crimeTypeFilter, locationFilter, dateRange]);

  const metrics = useMemo(() => getMetrics(filteredData), [filteredData]);
  const trends = useMemo(() => getMonthlyTrends(filteredData), [filteredData]);
  const insights = useMemo(() => getInsights(filteredData), [filteredData]);

  return (
    <div className="container py-8 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Crime Dashboard</h1>
          <p className="text-muted-foreground text-sm">
            Analyzing {filteredData.length} crime records
            {source === "uploaded" ? " (uploaded dataset)" : " (demo dataset)"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv"
            className="hidden"
            onChange={async e => {
              const input = e.currentTarget;
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setIsUploading(true);
                await uploadCsv(f);
                toast({
                  title: "Upload complete",
                  description: `Loaded ${f.name}${droppedInvalidCoords ? ` (dropped ${droppedInvalidCoords} invalid coords)` : ""}.`,
                });
              } catch (err) {
                console.error(err);
                toast({
                  variant: "destructive",
                  title: "Upload failed",
                  description: err instanceof Error ? err.message : "Could not upload CSV.",
                });
              } finally {
                setIsUploading(false);
                input.value = "";
              }
            }}
          />
          <Button variant="outline" size="sm" disabled={isUploading} onClick={() => fileRef.current?.click()}>
            {isUploading ? "Uploading…" : "Upload CSV"}
          </Button>
          {source === "uploaded" && (
            <Button variant="ghost" size="sm" onClick={clearUploaded}>
              Reset to demo
            </Button>
          )}
          <Button variant={view === "chart" ? "default" : "outline"} size="sm" className="gap-2" onClick={() => setView("chart")}>
            <BarChart3 className="h-4 w-4" /> Chart View
          </Button>
          <Button variant={view === "table" ? "default" : "outline"} size="sm" className="gap-2" onClick={() => setView("table")}>
            <Table className="h-4 w-4" /> Table View
          </Button>
        </div>
      </div>

      <DashboardFilters
        crimeType={crimeTypeFilter}
        setCrimeType={setCrimeTypeFilter}
        location={locationFilter}
        setLocation={setLocationFilter}
        dateRange={dateRange}
        setDateRange={setDateRange}
        crimeTypes={crimeTypeOptions}
        locations={locationOptions}
      />

      <MetricCards metrics={metrics} />

      {view === "chart" ? (
        <CrimeCharts metrics={metrics} trends={trends} />
      ) : (
        <CrimeTable data={filteredData} />
      )}

      <InsightsPanel insights={insights} />
    </div>
  );
}
