import { useCallback, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Upload, FileText, Shield, BarChart3, Map, Brain, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useDataset } from "@/context/DatasetContext";

const features = [
  { icon: BarChart3, title: "Interactive Charts", desc: "Bar, line, and pie charts with real-time tooltips" },
  { icon: Map, title: "Hotspot Maps", desc: "Heatmaps and markers showing crime density" },
  { icon: Brain, title: "Pattern Detection", desc: "AI-powered insights and trend analysis" },
  { icon: Shield, title: "Risk Assessment", desc: "Identify high-risk zones and time periods" },
];

export default function HomePage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { uploadCsv } = useDataset();
  const [dragging, setDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (isUploading) return;
    const f = e.dataTransfer.files?.[0];
    if (f) {
      setIsUploading(true);
      uploadCsv(f)
        .then(() => navigate("/dashboard"))
        .catch(err => {
          console.error(err);
          toast({
            variant: "destructive",
            title: "Upload failed",
            description: err instanceof Error ? err.message : "Could not upload CSV.",
          });
        })
        .finally(() => setIsUploading(false));
      return;
    }
    navigate("/dashboard");
  }, [isUploading, navigate, toast, uploadCsv]);

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-5" />
        <div className="container py-20 md:py-32 relative">
          <div className="max-w-3xl mx-auto text-center space-y-6 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <Shield className="h-4 w-4" />
              Crime Data Analysis Platform
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Analyze Crime Patterns with{" "}
              <span className="gradient-text">CrimeVision AI</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Upload your crime dataset and instantly visualize trends, detect hotspots,
              and uncover patterns through our interactive dashboard.
            </p>

            {/* Upload Area */}
            <div
              className={`mt-8 max-w-lg mx-auto border-2 border-dashed rounded-xl p-10 transition-all duration-300 cursor-pointer ${
                dragging
                  ? "border-primary bg-primary/10 scale-[1.02]"
                  : "border-border hover:border-primary/50 hover:bg-primary/5"
              } ${isUploading ? "opacity-60 pointer-events-none" : ""}`}
              onDragOver={e => { e.preventDefault(); if (!isUploading) setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileRef.current?.click()}
            >
              <input
                ref={fileRef}
                type="file"
                accept=".csv,text/csv"
                className="hidden"
                onChange={async e => {
                  const input = e.currentTarget;
                  const f = e.target.files?.[0];
                  if (!f) return;
                  try {
                    setIsUploading(true);
                    await uploadCsv(f);
                    navigate("/dashboard");
                  } catch (err) {
                    console.error(err);
                    toast({
                      variant: "destructive",
                      title: "Upload failed",
                      description: err instanceof Error ? err.message : "Could not upload CSV.",
                    });
                  } finally {
                    setIsUploading(false);
                    // React may clear synthetic event fields after awaits
                    input.value = "";
                  }
                }}
              />
              <Upload className={`h-10 w-10 mx-auto mb-4 transition-colors ${dragging ? "text-primary" : "text-muted-foreground"}`} />
              <p className="font-medium">{isUploading ? "Uploading & processing…" : "Upload crime dataset (CSV format)"}</p>
              <p className="text-sm text-muted-foreground mt-1">Drag & drop or click to browse</p>
              <div className="flex items-center justify-center gap-2 mt-4">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  Supported columns: Date, Crime Type, Location, Latitude, Longitude
                </span>
              </div>
            </div>

            <Button size="lg" className="gap-2 mt-4" onClick={() => navigate("/dashboard")}>
              Explore Demo Dashboard <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container py-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="glass-card rounded-xl p-6 hover:scale-[1.02] transition-all duration-300 animate-fade-in-up"
              style={{ animationDelay: `${i * 100}ms`, animationFillMode: "both" }}
            >
              <div className="p-2.5 rounded-lg gradient-primary w-fit mb-4">
                <f.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
