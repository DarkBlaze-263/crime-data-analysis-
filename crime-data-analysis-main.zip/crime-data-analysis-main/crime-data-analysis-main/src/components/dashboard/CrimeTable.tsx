import { CrimeRecord } from "@/data/mockCrimeData";
import { Badge } from "@/components/ui/badge";

export function CrimeTable({ data }: { data: CrimeRecord[] }) {
  return (
    <div className="glass-card rounded-xl overflow-hidden animate-fade-in">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border/50">
              {["Crime Type", "Date", "Time", "Location", "Lat", "Lng", "Severity"].map(h => (
                <th key={h} className="text-left px-4 py-3 text-muted-foreground font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.slice(0, 50).map(r => (
              <tr key={r.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                <td className="px-4 py-3 font-medium">{r.crimeType}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.date}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.time}</td>
                <td className="px-4 py-3">{r.location}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.latitude.toFixed(4)}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.longitude.toFixed(4)}</td>
                <td className="px-4 py-3">
                  <Badge variant={r.severity === "high" ? "destructive" : r.severity === "medium" ? "default" : "secondary"}>
                    {r.severity}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data.length > 50 && (
        <p className="text-center text-sm text-muted-foreground py-3">Showing 50 of {data.length} records</p>
      )}
    </div>
  );
}
