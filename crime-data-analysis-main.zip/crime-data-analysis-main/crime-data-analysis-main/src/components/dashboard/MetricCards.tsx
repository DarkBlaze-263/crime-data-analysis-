import { Shield, TrendingUp, MapPin, Clock } from "lucide-react";

interface MetricCardsProps {
  metrics: {
    total: number;
    mostCommonType: string;
    peakTime: string;
    dangerousArea: string;
  };
}

const cards = [
  { key: "total", label: "Total Crimes", icon: Shield, color: "text-primary" },
  { key: "mostCommonType", label: "Most Common Crime", icon: TrendingUp, color: "text-chart-4" },
  { key: "peakTime", label: "Peak Crime Time", icon: Clock, color: "text-chart-3" },
  { key: "dangerousArea", label: "Most Dangerous Area", icon: MapPin, color: "text-chart-5" },
] as const;

export function MetricCards({ metrics }: MetricCardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((c, i) => (
        <div
          key={c.key}
          className="glass-card rounded-xl p-5 hover:scale-[1.02] transition-all duration-300 animate-fade-in"
          style={{ animationDelay: `${i * 80}ms`, animationFillMode: "both" }}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground font-medium">{c.label}</span>
            <c.icon className={`h-5 w-5 ${c.color}`} />
          </div>
          <p className="text-2xl font-bold">{metrics[c.key]}</p>
          {c.key === "dangerousArea" && (
            <span className="inline-block mt-2 text-xs px-2 py-0.5 rounded-full bg-danger/10 text-danger font-medium">
              High Risk
            </span>
          )}
        </div>
      ))}
    </div>
  );
}
