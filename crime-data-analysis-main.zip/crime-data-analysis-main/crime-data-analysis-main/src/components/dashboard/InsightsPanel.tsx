import { AlertTriangle, Clock, MapPin, TrendingUp } from "lucide-react";

interface Insight {
  icon: string;
  text: string;
  type: "warning" | "danger";
}

const iconMap = {
  clock: Clock,
  alert: AlertTriangle,
  map: MapPin,
  trend: TrendingUp,
};

export function InsightsPanel({ insights }: { insights: Insight[] }) {
  return (
    <div className="space-y-3 animate-fade-in" style={{ animationDelay: "300ms" }}>
      <h3 className="font-semibold text-lg">Smart Insights</h3>
      <div className="grid sm:grid-cols-2 gap-3">
        {insights.map((ins, i) => {
          const Icon = iconMap[ins.icon as keyof typeof iconMap] || AlertTriangle;
          return (
            <div
              key={i}
              className={`flex items-start gap-3 glass-card rounded-xl p-4 border-l-4 ${
                ins.type === "danger" ? "border-l-danger" : "border-l-warning"
              }`}
            >
              <Icon className={`h-5 w-5 mt-0.5 shrink-0 ${ins.type === "danger" ? "text-danger" : "text-warning"}`} />
              <p className="text-sm">{ins.text}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
