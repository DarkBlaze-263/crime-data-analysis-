import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

const COLORS = [
  "hsl(210,100%,55%)", "hsl(168,80%,45%)", "hsl(280,65%,65%)",
  "hsl(38,92%,55%)", "hsl(0,72%,55%)", "hsl(200,80%,50%)",
  "hsl(150,70%,40%)", "hsl(320,60%,55%)", "hsl(45,90%,50%)", "hsl(180,60%,45%)"
];

interface Props {
  metrics: { typeCounts: Record<string, number>; hourCounts: Record<number, number> };
  trends: { month: string; count: number }[];
}

export function CrimeCharts({ metrics, trends }: Props) {
  const barData = Object.entries(metrics.typeCounts)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  const pieData = barData.slice(0, 6);

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Bar Chart */}
      <div className="glass-card rounded-xl p-5 animate-fade-in">
        <h3 className="font-semibold mb-4">Top Crime Types</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={barData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(224,15%,20%)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(215,15%,55%)" }} angle={-30} textAnchor="end" height={80} />
            <YAxis tick={{ fontSize: 12, fill: "hsl(215,15%,55%)" }} />
            <Tooltip contentStyle={{ background: "hsl(224,25%,12%)", border: "1px solid hsl(224,15%,20%)", borderRadius: "8px", color: "hsl(210,20%,94%)" }} />
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {barData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Line Chart */}
      <div className="glass-card rounded-xl p-5 animate-fade-in" style={{ animationDelay: "100ms" }}>
        <h3 className="font-semibold mb-4">Crime Trends Over Time</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={trends}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(224,15%,20%)" />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: "hsl(215,15%,55%)" }} />
            <YAxis tick={{ fontSize: 12, fill: "hsl(215,15%,55%)" }} />
            <Tooltip contentStyle={{ background: "hsl(224,25%,12%)", border: "1px solid hsl(224,15%,20%)", borderRadius: "8px", color: "hsl(210,20%,94%)" }} />
            <Line type="monotone" dataKey="count" stroke="hsl(210,100%,55%)" strokeWidth={2} dot={{ fill: "hsl(210,100%,55%)", r: 4 }} activeDot={{ r: 6 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Pie Chart */}
      <div className="glass-card rounded-xl p-5 lg:col-span-2 animate-fade-in" style={{ animationDelay: "200ms" }}>
        <h3 className="font-semibold mb-4">Crime Distribution</h3>
        <ResponsiveContainer width="100%" height={350}>
          <PieChart>
            <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={120} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine>
              {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Pie>
            <Tooltip contentStyle={{ background: "hsl(224,25%,12%)", border: "1px solid hsl(224,15%,20%)", borderRadius: "8px", color: "hsl(210,20%,94%)" }} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
