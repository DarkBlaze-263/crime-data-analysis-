import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Filter, X } from "lucide-react";

interface Props {
  crimeType: string;
  setCrimeType: (v: string) => void;
  location: string;
  setLocation: (v: string) => void;
  dateRange: { from?: Date; to?: Date };
  setDateRange: (v: { from?: Date; to?: Date }) => void;
  crimeTypes: string[];
  locations: string[];
}

export function DashboardFilters({ crimeType, setCrimeType, location, setLocation, dateRange, setDateRange, crimeTypes, locations }: Props) {
  const hasFilters = crimeType !== "all" || location !== "all" || dateRange.from || dateRange.to;

  return (
    <div className="glass-card rounded-xl p-4 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Filter className="h-4 w-4" /> Filters
        </div>
        <Select value={crimeType} onValueChange={setCrimeType}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Crime Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Crime Types</SelectItem>
            {crimeTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={location} onValueChange={setLocation}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Location" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Locations</SelectItem>
            {locations.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
        <input
          type="date"
          className="h-9 rounded-md border border-input bg-background px-3 text-sm"
          value={dateRange.from?.toISOString().split("T")[0] || ""}
          onChange={e => setDateRange({ ...dateRange, from: e.target.value ? new Date(e.target.value) : undefined })}
          placeholder="From"
        />
        <input
          type="date"
          className="h-9 rounded-md border border-input bg-background px-3 text-sm"
          value={dateRange.to?.toISOString().split("T")[0] || ""}
          onChange={e => setDateRange({ ...dateRange, to: e.target.value ? new Date(e.target.value) : undefined })}
          placeholder="To"
        />
        {hasFilters && (
          <Button variant="ghost" size="sm" className="gap-1" onClick={() => { setCrimeType("all"); setLocation("all"); setDateRange({}); }}>
            <X className="h-3 w-3" /> Clear
          </Button>
        )}
      </div>
    </div>
  );
}
