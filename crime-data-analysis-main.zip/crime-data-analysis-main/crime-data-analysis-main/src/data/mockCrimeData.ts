export interface CrimeRecord {
  id: number;
  date: string;
  time: string;
  crimeType: string;
  location: string;
  latitude: number;
  longitude: number;
  severity: "low" | "medium" | "high";
}

const crimeTypes = ["Theft", "Assault", "Burglary", "Robbery", "Vandalism", "Fraud", "Drug Offense", "DUI", "Homicide", "Arson"];
const locations = [
  { name: "Downtown", lat: 40.7128, lng: -74.006 },
  { name: "Midtown", lat: 40.7549, lng: -73.984 },
  { name: "East Side", lat: 40.7681, lng: -73.9563 },
  { name: "West End", lat: 40.7831, lng: -73.9712 },
  { name: "South District", lat: 40.6892, lng: -74.0445 },
  { name: "North Quarter", lat: 40.8007, lng: -73.9581 },
  { name: "Harbor Area", lat: 40.6892, lng: -74.0165 },
  { name: "Central Park Area", lat: 40.7829, lng: -73.9654 },
  { name: "Financial District", lat: 40.7075, lng: -74.0021 },
  { name: "University Zone", lat: 40.7295, lng: -73.9965 },
];

function randomBetween(a: number, b: number) { return a + Math.random() * (b - a); }

function generateRecords(count: number): CrimeRecord[] {
  const records: CrimeRecord[] = [];
  for (let i = 0; i < count; i++) {
    const loc = locations[Math.floor(Math.random() * locations.length)];
    const type = crimeTypes[Math.floor(Math.random() * crimeTypes.length)];
    const month = Math.floor(Math.random() * 12) + 1;
    const day = Math.floor(Math.random() * 28) + 1;
    const hour = Math.random() < 0.6 ? Math.floor(randomBetween(18, 24)) % 24 : Math.floor(randomBetween(0, 18));
    const minute = Math.floor(Math.random() * 60);
    const severity: CrimeRecord["severity"] = ["Homicide", "Arson", "Robbery"].includes(type) ? "high" : ["Assault", "Burglary", "Drug Offense"].includes(type) ? "medium" : "low";
    records.push({
      id: i + 1,
      date: `2024-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
      time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
      crimeType: type,
      location: loc.name,
      latitude: loc.lat + randomBetween(-0.005, 0.005),
      longitude: loc.lng + randomBetween(-0.005, 0.005),
      severity,
    });
  }
  return records.sort((a, b) => a.date.localeCompare(b.date));
}

export const mockCrimeData = generateRecords(500);

export const crimeTypeOptions = crimeTypes;
export const locationOptions = locations.map(l => l.name);

export function getMetrics(data: CrimeRecord[]) {
  const total = data.length;
  const typeCounts: Record<string, number> = {};
  const hourCounts: Record<number, number> = {};
  const areaCounts: Record<string, number> = {};

  data.forEach(r => {
    typeCounts[r.crimeType] = (typeCounts[r.crimeType] || 0) + 1;
    const h = parseInt(r.time.split(":")[0]);
    hourCounts[h] = (hourCounts[h] || 0) + 1;
    areaCounts[r.location] = (areaCounts[r.location] || 0) + 1;
  });

  const mostCommonType = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "N/A";
  const peakHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0];
  const peakTime = peakHour ? `${peakHour[0].padStart(2, "0")}:00` : "N/A";
  const dangerousArea = Object.entries(areaCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "N/A";

  return { total, mostCommonType, peakTime, dangerousArea, typeCounts, hourCounts, areaCounts };
}

export function getMonthlyTrends(data: CrimeRecord[]) {
  const months: Record<string, number> = {};
  data.forEach(r => {
    const m = r.date.substring(0, 7);
    months[m] = (months[m] || 0) + 1;
  });
  return Object.entries(months).sort((a, b) => a[0].localeCompare(b[0])).map(([month, count]) => ({ month, count }));
}

export function getInsights(data: CrimeRecord[]) {
  const metrics = getMetrics(data);
  const avgPerArea = data.length / Object.keys(metrics.areaCounts).length;
  const topArea = Object.entries(metrics.areaCounts).sort((a, b) => b[1] - a[1])[0];
  const pctAbove = topArea ? Math.round(((topArea[1] - avgPerArea) / avgPerArea) * 100) : 0;

  return [
    { icon: "clock", text: `Most crimes occur around ${metrics.peakTime}`, type: "warning" as const },
    { icon: "alert", text: `${metrics.mostCommonType} is the most frequent crime type`, type: "danger" as const },
    { icon: "map", text: `${metrics.dangerousArea} has the highest crime rate`, type: "danger" as const },
    { icon: "trend", text: `${pctAbove}% more crimes than average in ${topArea?.[0]}`, type: "warning" as const },
  ];
}
