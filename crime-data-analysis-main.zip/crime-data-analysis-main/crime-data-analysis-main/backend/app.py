from __future__ import annotations

import logging
import time
from typing import Any

import pandas as pd
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi import Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool


app = FastAPI(title="CrimeVision Backend")
logger = logging.getLogger("crimevision.backend")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s - %(message)s")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
        "http://localhost:8081",
        "http://127.0.0.1:8081",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def request_log_middleware(request: Request, call_next):
    started = time.perf_counter()
    logger.info("request started method=%s path=%s", request.method, request.url.path)
    response = await call_next(request)
    elapsed_ms = round((time.perf_counter() - started) * 1000)
    logger.info(
        "request finished method=%s path=%s status=%s elapsed_ms=%s",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    return response


class UploadResponse(BaseModel):
    records: list[dict[str, Any]]
    center: dict[str, float] | None
    dropped_invalid_coords: int


def _norm_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # Normalize whitespace so "Primary  Type" matches "Primary Type", etc.
    df.columns = [" ".join(str(c).strip().split()) for c in df.columns]
    return df


def _find_col(cols: list[str], candidates: list[str]) -> str | None:
    lowered = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in lowered:
            return lowered[cand.lower()]
    return None


def _severity(crime_type: str) -> str:
    t = (crime_type or "").strip().lower()
    if any(k in t for k in ["homicide", "murder", "arson", "robbery"]):
        return "high"
    if any(k in t for k in ["assault", "battery", "burglary", "drug"]):
        return "medium"
    return "low"


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/upload", response_model=UploadResponse)
async def upload_file(file: UploadFile = File(...)):
    logger.info("upload requested filename=%s content_type=%s", file.filename, file.content_type)

    def _process() -> dict[str, Any]:
        # Read CSV (CPU / IO heavy) in threadpool to avoid blocking the event loop.
        try:
            df = pd.read_csv(file.file)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Could not read CSV: {e}") from e

        df = _norm_cols(df)
        cols = list(df.columns)

        lat_col = _find_col(cols, ["Latitude", "Lat", "latitude", "lat"])
        lon_col = _find_col(cols, ["Longitude", "Lon", "Lng", "longitude", "lon", "lng"])
        if not lat_col or not lon_col:
            raise HTTPException(
                status_code=400,
                detail="CSV must include latitude/longitude columns (e.g. Latitude/Longitude or lat/lng).",
            )

        # Coerce coords to numbers
        df[lat_col] = pd.to_numeric(df[lat_col], errors="coerce")
        df[lon_col] = pd.to_numeric(df[lon_col], errors="coerce")

        before = len(df)
        df = df.dropna(subset=[lat_col, lon_col])
        df = df[
            (df[lat_col] >= -90)
            & (df[lat_col] <= 90)
            & (df[lon_col] >= -180)
            & (df[lon_col] <= 180)
            & ~((df[lat_col] == 0) & (df[lon_col] == 0))
        ].copy()
        dropped_invalid = before - len(df)

        # Optional semantic columns
        date_col = _find_col(cols, ["Date", "date", "Datetime", "datetime", "Timestamp", "timestamp"])
        type_col = _find_col(cols, ["Primary Type", "Crime Type", "Type", "primary type", "crimeType"])
        loc_col = _find_col(cols, ["Location", "Block", "Location Description", "location"])

        if date_col:
            dt = pd.to_datetime(df[date_col], errors="coerce")
            df["_date"] = dt.dt.date.astype("string")
            df["_time"] = dt.dt.strftime("%H:%M").fillna("")
        else:
            df["_date"] = ""
            df["_time"] = ""

        if type_col:
            df["_crimeType"] = df[type_col].astype("string").fillna("Unknown")
        else:
            df["_crimeType"] = "Unknown"

        if loc_col:
            df["_location"] = df[loc_col].astype("string").fillna("Unknown")
        else:
            df["_location"] = "Unknown"

        # Compute center (mean of valid points)
        center = None
        if len(df) > 0:
            center = {
                "lat": float(df[lat_col].mean()),
                "lng": float(df[lon_col].mean()),
            }

        out = pd.DataFrame(
            {
                "date": df["_date"].astype("string"),
                "time": df["_time"].astype("string"),
                "crimeType": df["_crimeType"].astype("string"),
                "location": df["_location"].astype("string"),
                "latitude": df[lat_col].astype("float64"),
                "longitude": df[lon_col].astype("float64"),
            }
        ).fillna("")
        out["severity"] = out["crimeType"].map(lambda x: _severity(str(x)))

        records: list[dict[str, Any]] = []
        for i, r in enumerate(out.to_dict(orient="records"), start=1):
            r["id"] = i
            r["latitude"] = float(r["latitude"])
            r["longitude"] = float(r["longitude"])
            records.append(r)

        logger.info("upload parsed records=%s dropped_invalid=%s", len(records), dropped_invalid)
        return {
            "records": records,
            "center": center,
            "dropped_invalid_coords": dropped_invalid,
        }

    return await run_in_threadpool(_process)