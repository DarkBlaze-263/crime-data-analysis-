"""Backend package marker.

This allows running uvicorn with: `uvicorn backend.app:app --reload`
"""

